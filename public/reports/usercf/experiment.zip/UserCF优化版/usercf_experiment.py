"""MovieLens 100K UserCF：三种相似度、验证集选参和独立测试。

Python 3.10+。运行说明见 README.md；数据中的 0 仅表示缺失评分。
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import platform
import statistics
import time
import urllib.request
import zipfile
from pathlib import Path

# 固定计算线程，避免参数之间的计时受到线程数量变化影响。
for _name in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_name] = "1"
import numpy as np

SEED = 20261005
TOP_N = 10
K_VALUES = (5, 10, 20, 40, 80)
METHODS = ("cosine", "jaccard", "pearson")
MIN_COMMON = 3
DATA_URL = "https://files.grouplens.org/datasets/movielens/ml-100k.zip"


def download_data(data_dir: Path) -> None:
    """从 GroupLens 下载；仅写入明确指定的三个数据文件。"""
    data_dir.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(DATA_URL, timeout=60) as response:
        archive = zipfile.ZipFile(io.BytesIO(response.read()))
    with archive:
        for filename in ("u.data", "u.item", "README"):
            target = data_dir / filename
            if not target.exists():
                target.write_bytes(archive.read("ml-100k/" + filename))


def load_data(data_dir: Path) -> tuple[np.ndarray, dict[int, str], dict]:
    """验证评分范围、ID和重复交互；返回连续ID对应的密集评分矩阵。"""
    rows = np.loadtxt(data_dir / "u.data", dtype=np.int64)
    if rows.ndim != 2 or rows.shape[1] != 4:
        raise ValueError("u.data 必须包含 user_id、item_id、rating、timestamp 四列")
    if (rows[:, :2] < 1).any() or not np.isin(rows[:, 2], [1, 2, 3, 4, 5]).all():
        raise ValueError("用户/物品ID应为正整数，评分应在1至5之间")
    if len(np.unique(rows[:, :2], axis=0)) != len(rows):
        raise ValueError("存在重复用户—物品记录，请先明确重复评分处理规则")
    users, items = int(rows[:, 0].max()), int(rows[:, 1].max())
    if not np.array_equal(np.unique(rows[:, 0]), np.arange(1, users + 1)):
        raise ValueError("本实验要求用户ID连续，其他数据集需先重新编码")
    full = np.zeros((users, items), dtype=np.float64)
    full[rows[:, 0] - 1, rows[:, 1] - 1] = rows[:, 2]
    titles = {}
    for line in (data_dir / "u.item").read_text(encoding="latin-1").splitlines():
        fields = line.split("|")
        titles[int(fields[0]) - 1] = fields[1]
    metadata = {
        "name": "MovieLens 100K", "users": users, "items": items,
        "ratings": len(rows), "density": len(rows) / full.size,
        "sparsity": 1 - len(rows) / full.size,
        "rating_range": [int(rows[:, 2].min()), int(rows[:, 2].max())],
        "sha256_u_data": hashlib.sha256((data_dir / "u.data").read_bytes()).hexdigest(),
        "duplicate_pairs": 0,
    }
    return full, titles, metadata


def split_by_user(full: np.ndarray, seed: int = SEED) -> tuple[np.ndarray, ...]:
    """按用户随机拆分约60%/20%/20%；每人至少保留一条训练记录。"""
    train = full.copy()
    validation = np.zeros_like(full)
    test = np.zeros_like(full)
    for user in range(len(full)):
        items = np.flatnonzero(full[user] > 0)
        if len(items) < 3:
            raise ValueError("每个用户至少需要3条评分才能进行三路拆分")
        rng = np.random.default_rng(seed + user)
        shuffled = rng.permutation(items)
        count = max(1, int(len(items) * 0.2))
        test_items, val_items = shuffled[:count], shuffled[count:2 * count]
        test[user, test_items] = full[user, test_items]
        validation[user, val_items] = full[user, val_items]
        train[user, shuffled[:2 * count]] = 0
    assert not np.any((train > 0) & ((validation > 0) | (test > 0)))
    assert not np.any((validation > 0) & (test > 0))
    np.testing.assert_array_equal(train + validation + test, full)
    return train, validation, test


def calc_similarity(ratings: np.ndarray, method: str,
                    min_common: int = MIN_COMMON) -> np.ndarray:
    """计算对称用户相似度矩阵；只使用当前训练数据，不含用户自身。

    cosine：零填充评分向量余弦，范数使用用户所有训练评分。
    jaccard：已评分物品集合交并比，忽略评分高低。
    pearson：仅在两人共同评分集合上计算均值、方差和相关系数。
    """
    if min_common < 1:
        raise ValueError("min_common 必须为正整数")
    ratings = np.asarray(ratings, dtype=np.float64)
    mask = (ratings > 0).astype(np.float64)
    common = mask @ mask.T
    if method == "cosine":
        numerator = ratings @ ratings.T
        norms = np.linalg.norm(ratings, axis=1)
        denominator = np.outer(norms, norms)
    elif method == "jaccard":
        numerator = common
        counts = mask.sum(axis=1)
        denominator = counts[:, None] + counts[None, :] - common
    elif method == "pearson":
        # sums[u,v] 只累加 u、v 共同评分物品上 u 的评分。
        sums = ratings @ mask.T
        squares = (ratings * ratings) @ mask.T
        safe_count = np.maximum(common, 1)
        numerator = ratings @ ratings.T - sums * sums.T / safe_count
        variance = np.maximum(squares - sums * sums / safe_count, 0)
        denominator = np.sqrt(variance * variance.T)
    else:
        raise ValueError("method 应为 cosine、jaccard 或 pearson")
    similarity = np.divide(numerator, denominator,
                           out=np.zeros_like(numerator), where=denominator > 1e-12)
    similarity[common < min_common] = 0
    similarity = np.clip(similarity, -1, 1)
    np.fill_diagonal(similarity, 0)
    return similarity


def get_top_k_users(similarity: np.ndarray, user: int, k: int) -> np.ndarray:
    """选择至多K名正相似度邻居；并列时按用户ID升序。"""
    if k < 1:
        raise ValueError("k 必须为正整数")
    candidates = np.flatnonzero(similarity[user] > 0)
    candidates = candidates[candidates != user]
    order = np.lexsort((candidates, -similarity[user, candidates]))
    return candidates[order[:k]]


def generate_recommendations(ratings: np.ndarray, similarity: np.ndarray,
                             user: int, k: int, top_n: int = TOP_N
                             ) -> list[tuple[int, float]]:
    """邻居高分行为加权投票；返回(0基物品ID, 排序分)，不预测星级。

    score(u,i) = sum(sim(u,v) * 1[r(v,i)>=4]) / sum(sim(u,v))。
    分母对同一用户的所有候选相同，避免单个五星评分自动获得满分。
    """
    if top_n < 1:
        raise ValueError("top_n 必须为正整数")
    neighbors = get_top_k_users(similarity, user, k)
    if not len(neighbors):
        return []
    weights = similarity[user, neighbors]
    scores = (weights @ (ratings[neighbors] >= 4)) / weights.sum()
    candidates = np.flatnonzero((ratings[user] == 0) & (scores > 0))
    order = np.lexsort((candidates, -scores[candidates]))
    return [(int(i), float(scores[i])) for i in candidates[order[:top_n]]]


def recommend_all(train: np.ndarray, similarity: np.ndarray, k: int,
                  top_n: int = TOP_N) -> list[list[tuple[int, float]]]:
    return [generate_recommendations(train, similarity, u, k, top_n)
            for u in range(len(train))]


def evaluate(recommendations: list[list[tuple[int, float]]],
             heldout: np.ndarray, top_n: int = TOP_N) -> dict:
    """P@N对全部用户平均且分母固定N；Recall只对存在留出正例者平均。

    空推荐保留并计零。Coverage按全部用户推荐并集/完整物品目录计算。
    """
    heldout = np.asarray(heldout)
    if heldout.ndim != 2 or 0 in heldout.shape:
        raise ValueError("heldout 必须是非空二维矩阵")
    if len(recommendations) != len(heldout) or top_n < 1:
        raise ValueError("用户数量不一致或top_n无效")
    hits_total, relevant_users, recall_sum = 0, 0, 0.0
    union = set()
    lengths = []
    for user, recs in enumerate(recommendations):
        ids = [item for item, score in recs]
        if any(not isinstance(i, (int, np.integer)) or i < 0 or i >= heldout.shape[1] for i in ids):
            raise ValueError("推荐物品ID必须是目录范围内的整数")
        if len(ids) > top_n or len(ids) != len(set(ids)):
            raise ValueError("推荐列表过长或含重复物品")
        relevant = set(np.flatnonzero(heldout[user] >= 4).tolist())
        hits = len(relevant.intersection(ids))
        hits_total += hits
        if relevant:
            relevant_users += 1
            recall_sum += hits / len(relevant)
        union.update(ids)
        lengths.append(len(ids))
    return {
        f"precision_at_{top_n}": hits_total / (len(heldout) * top_n),
        f"recall_at_{top_n}": recall_sum / relevant_users if relevant_users else 0.0,
        "catalog_coverage": len(union) / heldout.shape[1],
        "user_coverage": sum(n > 0 for n in lengths) / len(heldout),
        "mean_list_length": float(np.mean(lengths)),
        "precision_users": len(heldout), "recall_users": relevant_users,
        "total_hits": hits_total, "recommended_distinct_items": len(union),
    }


def measured(function, repeats: int = 3):
    """相同输入预热一次后重复计时；不包含数据加载和画图。"""
    function()
    samples = []
    for _ in range(repeats):
        start = time.perf_counter()
        value = function()
        samples.append(time.perf_counter() - start)
    return value, statistics.median(samples), samples


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def make_plots(result: dict, matrices: dict, output: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 11, "axes.spines.top": False,
                         "axes.spines.right": False, "figure.dpi": 150})
    colors = {"cosine": "#2463A5", "jaccard": "#00816A", "pearson": "#BF5C20"}
    for metric, title, filename in (
        ("precision_at_10", "Validation Precision@10", "topk_precision.png"),
        ("catalog_coverage", "Validation catalog coverage", "topk_coverage.png"),
        ("recommendation_s", "Recommendation time (943 users)", "topk_runtime.png"),
    ):
        fig, ax = plt.subplots(figsize=(8.2, 4.2), layout="constrained")
        for method in METHODS:
            rows = [r for r in result["validation_results"] if r["method"] == method]
            ax.plot([r["k"] for r in rows], [r[metric] for r in rows],
                    "o-", label=method.title(), color=colors[method], linewidth=2)
        ax.set(xlabel="Number of neighbors K", ylabel=title, xticks=K_VALUES)
        ax.grid(alpha=0.2)
        ax.legend(frameon=False)
        fig.savefig(output / filename, dpi=200)
        plt.close(fig)
    fig, ax = plt.subplots(figsize=(8.2, 4.2), layout="constrained")
    rows = result["scaling_results"]
    for key, label in (("similarity_s", "Similarity"),
                       ("recommendation_s", "Recommendations")):
        ax.plot([r["users"] for r in rows], [r[key] for r in rows], "o-", label=label)
    ax.set(xlabel="Number of users (fixed movie catalog)", ylabel="Median time (s)")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)
    fig.savefig(output / "runtime_scaling.png", dpi=200)
    plt.close(fig)
    fig, axes = plt.subplots(1, 3, figsize=(7.3, 2.6), layout="constrained")
    for ax, method in zip(axes, METHODS):
        im = ax.imshow(matrices[method][:6, :6], vmin=-1, vmax=1, cmap="RdBu_r")
        ax.set(title=method.title(), xticks=range(6), yticks=range(6),
               xticklabels=range(1, 7), yticklabels=range(1, 7), xlabel="User ID")
        for i in range(6):
            for j in range(6):
                ax.text(j, i, f"{matrices[method][i,j]:.2f}", ha="center", va="center", fontsize=8.8)
    fig.colorbar(im, ax=axes, shrink=0.8, label="Similarity")
    fig.savefig(output / "similarity_matrices.png", dpi=200)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).parent / "data" / "ml-100k")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).parent / "results")
    parser.add_argument("--download", action="store_true", help="下载缺失的MovieLens数据")
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()
    if args.download:
        download_data(args.data_dir)
    if not (args.data_dir / "u.data").exists():
        parser.error("缺少数据，请使用 --download 或 --data-dir 指向 ml-100k 文件夹")
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    full, titles, dataset = load_data(args.data_dir)
    train, validation, test = split_by_user(full, args.seed)
    for name, data in (("train", train), ("validation", validation), ("test", test)):
        dataset[name + "_ratings"] = int(np.count_nonzero(data))
        dataset[name + "_positives"] = int(np.count_nonzero(data >= 4))
    dataset["train_catalog_items"] = int(np.count_nonzero((train > 0).any(axis=0)))
    matrices, rows = {}, []
    for method in METHODS:
        sim, sim_s, sim_samples = measured(lambda: calc_similarity(train, method))
        matrices[method] = sim
        for k in K_VALUES:
            recs, rec_s, rec_samples = measured(lambda: recommend_all(train, sim, k))
            row = {"method": method, "k": k, **evaluate(recs, validation),
                   "similarity_s": sim_s, "recommendation_s": rec_s,
                   "similarity_samples_s": sim_samples, "recommendation_samples_s": rec_samples}
            rows.append(row)
            print(f"validation {method:7s} K={k:2d} P@10={row['precision_at_10']:.4f} "
                  f"coverage={row['catalog_coverage']:.4f}", flush=True)
    # 只用验证集选择配置。并列时先Recall，再较小K，最后方法名。
    best = sorted(rows, key=lambda r: (-r["precision_at_10"], -r["recall_at_10"],
                                       r["k"], r["method"]))[0]
    final_train = train + validation
    final_sim, final_sim_s, _ = measured(lambda: calc_similarity(final_train, best["method"]))
    final_recs, final_rec_s, _ = measured(lambda: recommend_all(final_train, final_sim, best["k"]))
    final_metrics = evaluate(final_recs, test)
    # 同一测试集上的简单基线；只使用最终训练集中的高分次数排序。
    likes = (final_train >= 4).sum(axis=0)
    baseline = []
    for user in range(len(full)):
        candidates = np.flatnonzero((final_train[user] == 0) & (likes > 0))
        order = np.lexsort((candidates, -likes[candidates]))
        baseline.append([(int(i), float(likes[i])) for i in candidates[order[:TOP_N]]])
    # 嵌套随机用户子集，保持物品维度、每个子集的输入和计时重复一致。
    scaling = []
    permutation = np.random.default_rng(args.seed).permutation(len(train))
    for fraction in (0.25, 0.5, 0.75, 1.0):
        count = round(len(train) * fraction)
        sample = train[permutation[:count]]
        sim, sim_s, sim_samples = measured(lambda: calc_similarity(sample, "cosine"))
        _, rec_s, rec_samples = measured(lambda: recommend_all(sample, sim, 20))
        scaling.append({"users": count, "items": full.shape[1],
                        "train_ratings": int(np.count_nonzero(sample)),
                        "similarity_s": sim_s, "recommendation_s": rec_s,
                        "similarity_samples_s": sim_samples, "recommendation_samples_s": rec_samples})
    sample_recs = []
    for rank, (item, score) in enumerate(final_recs[0], 1):
        sample_recs.append({"rank": rank, "item_id": item + 1, "title": titles[item],
                            "ranking_score": score,
                            "heldout_rating": int(test[0, item]) if test[0, item] else None,
                            "test_hit": bool(test[0, item] >= 4)})
    neighbors = get_top_k_users(final_sim, 0, best["k"])
    result = {
        "metadata": {"timestamp": time.strftime("%Y-%m-%d %H:%M:%S %z"),
                     "python": platform.python_version(), "numpy": np.__version__,
                     "platform": platform.platform(), "processor": platform.processor(),
                     "seed": args.seed, "blas_thread_limit": 1, "timing_repeats": 3,
                     "top_n": TOP_N, "min_common": MIN_COMMON,
                     "split": "per-user random approximately 60/20/20"},
        "dataset": dataset, "validation_results": rows,
        "selected_config": {"method": best["method"], "k": best["k"],
                            "validation_precision_at_10": best["precision_at_10"],
                            "validation_recall_at_10": best["recall_at_10"]},
        "test_results": {"usercf": final_metrics, "popularity": evaluate(baseline, test)},
        "final_training": {"ratings": int(np.count_nonzero(final_train)),
                           "catalog_items": int(np.count_nonzero((final_train > 0).any(axis=0))),
                           "similarity_s": final_sim_s, "recommendation_s": final_rec_s},
        "scaling_results": scaling,
        "sample_user_id": 1, "sample_recommendations": sample_recs,
        "sample_neighbors": [{"user_id": int(u + 1), "similarity": float(final_sim[0,u])}
                             for u in neighbors[:10]],
        "sources": ["https://grouplens.org/datasets/movielens/100k/",
                    "https://files.grouplens.org/datasets/movielens/ml-100k-README.txt",
                    "https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.pearsonr.html"],
    }
    (output / "experiment_results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(output / "validation_metrics.csv", [{k:v for k,v in r.items() if not isinstance(v, list)} for r in rows])
    write_csv(output / "test_metrics.csv", [{"method": name, **metrics} for name, metrics in result["test_results"].items()])
    write_csv(output / "sample_recommendations.csv", sample_recs)
    write_csv(output / "scaling_metrics.csv", [{k:v for k,v in r.items() if not isinstance(v, list)} for r in scaling])
    np.savez_compressed(output / "similarity_matrices.npz", **matrices, final_selected=final_sim)
    for method, matrix in matrices.items():
        np.savetxt(output / f"similarity_{method}_first6.csv", matrix[:6,:6], delimiter=",", fmt="%.6f")
    make_plots(result, matrices, output)
    print(json.dumps({"selected": result["selected_config"], "test": result["test_results"]}, indent=2))


if __name__ == "__main__":
    main()
