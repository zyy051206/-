"""从实际运行的 results 文件生成可编辑 Word 实验报告。"""
from pathlib import Path
import json

from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
R = json.loads((RESULTS / "experiment_results.json").read_text(encoding="utf-8"))
D = R["dataset"]
BEST = R["selected_config"]
TEST = R["test_results"]["usercf"]
BASE = R["test_results"]["popularity"]
DOC = Document()
SEC = DOC.sections[0]
SEC.page_width, SEC.page_height = Cm(21), Cm(29.7)
SEC.top_margin, SEC.bottom_margin = Cm(1.7), Cm(1.65)
SEC.left_margin, SEC.right_margin = Cm(2), Cm(2)
SEC.footer_distance = Cm(0.75)


def font(style, size, east="宋体", latin="Calibri", bold=False):
    style.font.name = latin
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.color.rgb = RGBColor(0, 0, 0)
    style.element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), east)


for name, size in (("Normal", 11), ("Title", 22), ("Heading 1", 16), ("Heading 2", 12)):
    font(DOC.styles[name], size, "黑体" if name != "Normal" else "宋体", bold=name != "Normal")
    # 清除默认模板可能在标题样式中携带的装饰线。
    for border in DOC.styles[name].element.xpath(".//w:pBdr"):
        border.getparent().remove(border)
normal = DOC.styles["Normal"].paragraph_format
normal.line_spacing = 1.22
normal.space_after = Pt(6)
for name in ("Title", "Heading 1", "Heading 2"):
    DOC.styles[name].paragraph_format.space_before = Pt(9 if name != "Title" else 0)
    DOC.styles[name].paragraph_format.space_after = Pt(8)
    DOC.styles[name].paragraph_format.keep_with_next = True
font(DOC.styles["Caption"], 9, "宋体")
DOC.styles["Caption"].paragraph_format.space_after = Pt(6)
DOC.core_properties.title = "基于用户的协同过滤算法实验报告"
DOC.core_properties.subject = "MovieLens 100K UserCF 实现与参数评估"
DOC.core_properties.author = ""
DOC.core_properties.keywords = "UserCF, MovieLens 100K, Python"


def p(text="", bold=False):
    para = DOC.add_paragraph()
    para.add_run(text).bold = bold
    return para


def h(text, level=1):
    return DOC.add_heading(text, level)


def page(title):
    h(title).paragraph_format.page_break_before = True


def table(headers, rows, widths, size=10, padding=70):
    t = DOC.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    for col, width in zip(t.columns, widths):
        col.width = Cm(width)
    for cell, width, text in zip(t.rows[0].cells, widths, headers):
        cell.width = Cm(width)
        cell.text = str(text)
    for row in rows:
        cells = t.add_row().cells
        for cell, width, text in zip(cells, widths, row):
            cell.width = Cm(width)
            cell.text = str(text)
    props = t._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement("w:" + edge)
        for key, val in (("val", "single"), ("sz", "4"), ("color", "D9D9D9")):
            el.set(qn("w:" + key), val)
        borders.append(el)
    props.append(borders)
    margins = OxmlElement("w:tblCellMar")
    for side, value in (("top", str(padding)), ("bottom", str(padding)), ("left", "90"), ("right", "90")):
        el = OxmlElement("w:" + side)
        el.set(qn("w:w"), value)
        el.set(qn("w:type"), "dxa")
        margins.append(el)
    props.append(margins)
    for ri, row in enumerate(t.rows):
        no_split = OxmlElement("w:cantSplit")
        row._tr.get_or_add_trPr().append(no_split)
        if ri == 0:
            row._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for ci, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            shade = OxmlElement("w:shd")
            shade.set(qn("w:fill"), "E8EEF4" if ri == 0 else ("F7F8FA" if ri % 2 == 0 else "FFFFFF"))
            cell._tc.get_or_add_tcPr().append(shade)
            for para in cell.paragraphs:
                para.paragraph_format.space_after = Pt(0)
                para.paragraph_format.line_spacing = 1.12
                para.alignment = WD_ALIGN_PARAGRAPH.LEFT if ci == 0 or widths[ci] >= 7 else WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.name = "Calibri"
                    run.font.size = Pt(size)
                    run.bold = ri == 0
                    run.font.color.rgb = RGBColor(0, 0, 0)
                    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")
    DOC.add_paragraph().paragraph_format.space_after = Pt(0)
    return t


def figure(filename, caption, width=16.2):
    para = DOC.add_paragraph()
    para.paragraph_format.space_after = Pt(2)
    para.paragraph_format.keep_with_next = True
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = para.add_run()
    run.add_picture(str(RESULTS / filename), width=Cm(width))
    inline = run._r.xpath(".//wp:docPr")
    if inline:
        inline[0].set("descr", caption)
    cap = DOC.add_paragraph(caption, style="Caption")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER


def code(text):
    para = DOC.add_paragraph()
    para.paragraph_format.line_spacing = 1.05
    para.paragraph_format.space_after = Pt(8)
    para.paragraph_format.keep_together = True
    shade = OxmlElement("w:shd")
    shade.set(qn("w:fill"), "F4F5F6")
    para._p.get_or_add_pPr().append(shade)
    run = para.add_run(text.strip())
    run.font.name = "Consolas"
    run.font.size = Pt(9)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")


def mr(text):
    el = OxmlElement("m:r")
    t = OxmlElement("m:t")
    t.text = text
    el.append(t)
    return el


def equation(lhs, numerator, denominator):
    """使用原生 OMML 分式；避免将公式作为普通文本或截图插入。"""
    para = DOC.add_paragraph()
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    para.paragraph_format.space_after = Pt(8)
    math = OxmlElement("m:oMath")
    math.append(mr(lhs + " = "))
    frac = OxmlElement("m:f")
    num, den = OxmlElement("m:num"), OxmlElement("m:den")
    num.append(mr(numerator))
    den.append(mr(denominator))
    frac.extend((num, den))
    math.append(frac)
    para._p.append(math)


def pct(value):
    return f"{value * 100:.2f}%"


footer = SEC.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
footer.add_run("第 ")
field = OxmlElement("w:fldSimple")
field.set(qn("w:instr"), "PAGE")
footer._p.append(field)
footer.add_run(" 页")
for run in footer.runs:
    run.font.size = Pt(9)

# 第1页：直接进入实验主题，不设空白封面。
DOC.add_paragraph("基于用户的协同过滤算法实验报告", style="Title")
p("实验一  UserCF 算法实现与参数评估", bold=True)
p("姓名：________________    学号：________________    班级：________________")
p(f"运行日期：{R['metadata']['timestamp']}    数据集：MovieLens 100K")
p(f"本实验使用 Python 实现余弦、Jaccard 和 Pearson 三种用户相似度，比较不同邻居数量 K 的推荐效果。"
  f"验证集选出的配置为 {BEST['method'].title()}、K={BEST['k']}；独立测试集 Precision@10 为 {pct(TEST['precision_at_10'])}，"
  f"高于热门推荐基线的 {pct(BASE['precision_at_10'])}。结论仅针对本次固定划分与候选参数。")
h("一 实验目的", 2)
p("掌握从用户—物品交互记录构建 UserCF 推荐的完整流程，理解相似度、邻居数量与推荐列表长度的不同作用；"
  "用独立验证和测试数据评估准确率、召回率、覆盖率及运行时间，分析算法的适用场景和局限性。")
h("二 数据处理", 2)
p("采用 GroupLens 发布的 MovieLens 100K 电影评分数据 [1]。输入为用户ID、电影ID、评分和时间戳；本实验不使用人口属性。"
  "读取时检查字段数量、ID、1至5分评分范围和重复用户—电影记录，将ID映射为从0开始的矩阵下标。")
table(["数据项目", "实际统计"], [
    ["用户数 / 电影数", f"{D['users']} / {D['items']}"], ["评分记录 / 重复交互", f"{D['ratings']:,} / {D['duplicate_pairs']}"],
    ["交互密度 / 稀疏度", f"{pct(D['density'])} / {pct(D['sparsity'])}"],
    ["训练 / 验证 / 测试评分", f"{D['train_ratings']:,} / {D['validation_ratings']:,} / {D['test_ratings']:,}"],
    ["各集合中评分不少于4的记录", f"{D['train_positives']:,} / {D['validation_positives']:,} / {D['test_positives']:,}"],
    ["初始训练集中出现的电影", f"{D['train_catalog_items']} / {D['items']}"],
], [8.8, 8.2])
p("矩阵中的0只代表未观察到评分，不代表用户打了0分。保留全部电影ID作为目录，以免因为删去冷门或留出电影而缩小评估范围。")
h("三 实验环境", 2)
p(f"Python {R['metadata']['python']}，NumPy {R['metadata']['numpy']}，Matplotlib；Windows 11 64位。"
  "随机种子为20261005，BLAS线程配置设为1。图表、CSV和JSON由同一轮运行生成；完整可复现命令见报告末页和 README。")

page("四 算法原理与实现约定")
p("记 U 为用户数量、I 为电影数量，r(u,i) 为训练评分，Iu 为用户u已评分的电影集合，C为两名用户的共同评分集合。"
  "三种方法都只使用训练数据；共同评分少于3项时相似度置0，对角线置0，不将用户自身作为邻居。")
h("1 用户相似度", 2)
p("余弦相似度：将缺失位置填0，使用完整评分向量的夹角。分母使用各用户全部训练评分的范数；这种定义与只在共同评分集合上求余弦的变体不同。")
equation("cos(u,v)", "r(u) · r(v)", "‖r(u)‖ ‖r(v)‖")
p("Jaccard系数：比较两名用户已评分电影集合的重叠程度。它只使用交互是否出现的信息，不区分高分和低分。")
equation("J(u,v)", "|Iu ∩ Iv|", "|Iu ∪ Iv|")
p("Pearson相关系数：仅取共同评分集合C中的评分向量x和y，分别减去各自在C上的均值，再计算相关系数 [2]。任一方方差为0时置0。")
equation("ρ(u,v)", "(x − x̄) · (y − ȳ)", "‖x − x̄‖ ‖y − ȳ‖")
h("2 选择邻居并生成推荐", 2)
p("从正相似度用户中选出至多K名邻居。邻居按相似度降序排列，并列时按用户ID升序；负相关用户不参加正反馈投票。"
  "三种相似度统一使用以下 Top-N 排序分，N固定为10。")
equation("score(u,i)", "Σ 邻居相似度 × 1[该邻居对电影i评分 ≥ 4]", "Σ 全部入选邻居的相似度")
p("分母对同一用户的所有候选电影相同。已评分电影与得分为0的电影不进入推荐列表；得分相同时按电影ID升序。"
  "无有效邻居时返回空列表，候选不足10项时返回实际候选，不用测试数据或热门电影补齐。排序分不是预测星级。")
figure("similarity_matrices.png", "图1 初始训练集上用户1至6的相似度矩阵  对角线按排除自身的约定设为0", 16.7)

page("五 关键代码与程序结构")
p("核心实现位于 usercf_experiment.py。数据处理、相似度、邻居检索、推荐与评估分别封装为函数；下列代码展示最关键的计算步骤，完整边界检查见源文件。")
h("1 共同评分集合上的 Pearson", 2)
code("""mask = (ratings > 0).astype(np.float64)
common = mask @ mask.T
sums = ratings @ mask.T
squares = (ratings * ratings) @ mask.T
safe_count = np.maximum(common, 1)
numerator = ratings @ ratings.T - sums * sums.T / safe_count
variance = np.maximum(squares - sums * sums / safe_count, 0)
denominator = np.sqrt(variance * variance.T)
similarity = np.divide(
    numerator, denominator, out=np.zeros_like(numerator),
    where=denominator > 1e-12)
similarity[common < MIN_COMMON] = 0
np.fill_diagonal(similarity, 0)""")
p("sums[u,v]只汇总两名用户共同评分的电影上u的评分，squares同理。采用矩阵乘法同时计算所有用户对，避免逐对Python循环；"
  "使用float64并截断浮点舍入产生的微小负方差。")
h("2 推荐候选与确定性排序", 2)
code("""neighbors = get_top_k_users(similarity, user, k)
if not len(neighbors):
    return []
weights = similarity[user, neighbors]
scores = (weights @ (ratings[neighbors] >= 4)) / weights.sum()
candidates = np.flatnonzero((ratings[user] == 0) & (scores > 0))
order = np.lexsort((candidates, -scores[candidates]))
return [(int(i), float(scores[i]))
        for i in candidates[order[:top_n]]]""")
h("3 函数职责", 2)
table(["函数", "职责"], [
    ["load_data / split_by_user", "校验数据并生成互斥的三路划分"],
    ["calc_similarity", "计算并清理用户相似度矩阵"],
    ["get_top_k_users", "排除自身及非正相似度用户，取Top-K"],
    ["generate_recommendations", "计算候选得分并输出Top-N列表"],
    ["evaluate / measured", "计算统一指标及固定输入下的重复计时"],
], [7.4, 9.6], 10)
p("实现优化重点是正确的相似度、明确的数据隔离和一致的评估口径。矩阵运算改善执行效率，但当前教学实现仍保留完整用户相似度矩阵，未声称解决大规模存储问题。")

page("六 评估设计与复现控制")
h("1 训练 验证 测试的分工", 2)
p("对每个用户的已评分电影，使用固定随机种子打乱后，各取约20%作为测试集和验证集，剩余作为训练集。"
  "每人留出数量向下取整，因此实际总比例略有偏离。拆分验证互斥性与完整重构，不从留出评分计算用户相似度。")
p("用初始训练集训练15组配置：3种相似度 × K∈{5,10,20,40,80}。在验证集上比较 Precision@10；若并列，依次比较Recall、较小K和方法名。"
  "配置确定后，将训练集与验证集合并，重新计算相似度，再使用一直保留的测试集进行最终评估。")
h("2 相关电影和候选范围", 2)
p("留出集中评分不少于4分的电影定义为相关电影。推荐时从完整目录中排除当前训练集中已经评分的电影，"
  "不只在测试集中采样候选。未观察到的评分不等于真实不喜欢；本实验衡量的是已知留出正例能否被召回。")
h("3 指标定义", 2)
equation("Precision@10", "全部用户推荐命中数之和", "全部用户数 × 10")
p("Precision对全部943名用户计算，推荐不足10项仍以10为分母，空列表计0。避免通过跳过难推荐用户或缩短列表抬高准确率。")
equation("Recall@10", "Σ 每位有正例用户的 命中数 ÷ 该用户留出正例数", "留出集中至少有一个正例的用户数")
p(f"Recall采用宏平均。最终测试集中有{TEST['recall_users']}名用户具有正例，其余用户只参加Precision、目录覆盖率和用户覆盖率计算。")
equation("Catalog coverage", "所有目标用户推荐列表中不同电影的数量", "完整电影目录大小")
p("目录覆盖率分母固定为1682，包括训练集中没有出现的电影。用户覆盖率是能获得至少一条推荐的用户比例。"
  "覆盖率用于观察推荐广度，本身不能替代相关性指标。")
h("4 计时与正确性检查", 2)
p("相似度构建和全用户推荐分别预热一次，然后在相同输入上重复3次，取中位数。推荐计时包含选邻居、打分和排序，"
  "不包含指标计算、数据读写、下载和绘图。同一种相似度在不同K之间复用，构建耗时不应重复相加。")
p("独立测试覆盖手工相似度、共同评分Pearson、零方差、数据划分互斥与复现、邻居筛选、排除已评分电影、确定性排序、空与短列表，以及指标输入校验。"
  "运行命令为 python -m unittest -v test_usercf。")

page("七 验证集参数对比")
p("表1使用同一初始训练集和验证集。P@10为准确率，R@10为宏平均召回率，Coverage为目录覆盖率。N均为10，只有相似度方法与K变化。")
table(["相似度", "K", "P@10", "R@10", "Coverage"], [
    [r["method"].title(), r["k"], pct(r["precision_at_10"]), pct(r["recall_at_10"]), pct(r["catalog_coverage"])]
    for r in R["validation_results"]
], [4, 1.4, 3.5, 3.5, 4.6], padding=50)
figure("topk_precision.png", "图2 K与验证集 Precision@10 的关系", 15.8)
p(f"在本次15组候选中，{BEST['method'].title()}、K={BEST['k']}获得最高验证准确率{pct(BEST['validation_precision_at_10'])}。"
  "K=80处于本次网格上界，因此只能称为已测试候选中的最优配置，不能认定它是全局最优。")
p("当前K范围内，三种方法的准确率均随K增大而提高。更多邻居能提供更多高分行为信号；"
  "Pearson在本次协议下相对较弱，这一结果不足以说明它在所有评分预测或推荐任务中都较弱。")

page("八 覆盖率与参数耗时")
figure("topk_coverage.png", "图3 K与验证集目录覆盖率的关系", 16)
p("随着K增大，推荐覆盖的不同电影数量下降。加权高分投票在聚合更多邻居后，倾向让广泛受欢迎的电影进入前10名，"
  "这与图中的覆盖率变化一致。该解释基于排序机制，尚未通过额外消融实验隔离因果。")
figure("topk_runtime.png", "图4 K与全用户推荐耗时的关系  每个点为固定输入下3次运行的中位数", 16)
p("K增大意味着每个用户需要访问更多邻居评分。当前实现为每位用户取出K×I评分块，再进行投票与候选排序，因此推荐阶段耗时整体上升。"
  "系统调度、缓存和计时噪声会造成局部波动，曲线不应被理解为每次运行都严格单调。")
p("若应用同时关注准确率和长尾曝光，可以在验证集上设置覆盖率约束或增加多样性重排；本实验只以Precision选参，未为提高覆盖率而额外调整模型。")

page("九 独立测试与推荐示例")
p(f"按验证集确定{BEST['method'].title()}、K={BEST['k']}后，合并训练与验证数据，使用{R['final_training']['ratings']:,}条评分重新训练。"
  "热门推荐基线按同一最终训练集中的高分次数排序，同样排除目标用户已评分电影，并输出10项。")
table(["方法", "P@10", "R@10", "目录覆盖率", "用户覆盖率"], [
    [f"UserCF K={BEST['k']}", pct(TEST['precision_at_10']), pct(TEST['recall_at_10']), pct(TEST['catalog_coverage']), pct(TEST['user_coverage'])],
    ["热门推荐", pct(BASE['precision_at_10']), pct(BASE['recall_at_10']), pct(BASE['catalog_coverage']), pct(BASE['user_coverage'])],
], [4.3, 2.8, 2.8, 3.5, 3.6])
p(f"UserCF测试准确率比基线高{(TEST['precision_at_10']-BASE['precision_at_10'])*100:.2f}个百分点；"
  f"两者分别命中{TEST['total_hits']}和{BASE['total_hits']}个留出正例，推荐并集分别覆盖{TEST['recommended_distinct_items']}和{BASE['recommended_distinct_items']}部电影。"
  "这里比较的是同一测试集上的两个系统，未做显著性检验。")
h("用户1的前10项推荐", 2)
table(["序号", "电影ID及片名", "排序分", "测试评分"], [
    [r["rank"], f"{r['item_id']}  {r['title']}", f"{r['ranking_score']:.4f}",
     str(r["heldout_rating"]) if r["heldout_rating"] is not None else "未观察"]
    for r in R["sample_recommendations"]
], [1.2, 11, 2.2, 2.6], 9.5)
p("测试评分仅用于推荐生成后的对照。评分4或5为命中，未观察不表示不喜欢。用户1固定为展示样本，"
  "未按命中数挑选；其个体结果不能代表总体效果。完整ID、分数和命中标记见 sample_recommendations.csv。")
p("用户1最相似的前5名邻居为：" + "；".join(f"用户{x['user_id']}（{x['similarity']:.4f}）" for x in R["sample_neighbors"][:5]) + "。")
p("测试指标高于验证指标不应直接解释为模型改进：最终模型使用了更多训练评分，且两个留出集合不同。"
  "本次结果也不宜与旧版不同划分或不同指标口径的数值直接比较。")

page("十 性能与复杂度分析")
p("规模实验使用初始训练矩阵，固定电影目录为1682项，将用户按固定种子随机排列后取嵌套子集。"
  "所有规模均使用余弦相似度、K=20、N=10；同一规模的3次重复使用完全相同的数据。")
table(["用户数", "训练评分数", "相似度秒", "全用户推荐秒"], [
    [r["users"], f"{r['train_ratings']:,}", f"{r['similarity_s']:.4f}", f"{r['recommendation_s']:.4f}"]
    for r in R["scaling_results"]
], [3, 4, 4.5, 5.5])
figure("runtime_scaling.png", "图5 固定电影目录下的用户规模与分阶段运行时间", 15.8)
h("时间复杂度", 2)
p("三种密集矩阵相似度计算均为O(U²I)，但Pearson需要更多矩阵乘法，常数开销更大。"
  "每个用户的完整邻居排序为O(U log U)，投票为O(KI)，候选完整排序最坏为O(I log I)；"
  "全用户推荐为O(U² log U + UKI + UI log I)。多个K可复用同一相似度矩阵。")
h("空间复杂度", 2)
p(f"评分矩阵占O(UI)，单个相似度矩阵占O(U²)。本实验float64矩阵分别约占"
  f"{D['users']*D['items']*8/1024**2:.2f} MiB和{D['users']**2*8/1024**2:.2f} MiB；"
  "这是单数组大小，不是进程峰值内存。Pearson中间矩阵以及同时保留多个方法的结果会进一步增加内存。")
p("规模曲线只改变用户数，保持目录大小不变，不能据此证明对所有数据维度的渐近行为。"
  "面向更大规模时，可使用稀疏矩阵、分块相似度或只保存Top-K邻居；也可比较ItemCF与矩阵分解，"
  "但实际收益需根据用户数、物品数和稀疏度重新测量。")

page("十一 总结与运行说明")
h("实验结论", 2)
p(f"本实验完成了数据处理、三种相似度、Top-K邻居选择、Top-10推荐、验证选参及独立测试。"
  f"所测配置中{BEST['method'].title()}、K={BEST['k']}验证表现最好；在独立测试集上，Precision@10={pct(TEST['precision_at_10'])}，"
  f"Recall@10={pct(TEST['recall_at_10'])}，目录覆盖率={pct(TEST['catalog_coverage'])}。")
p("UserCF能利用相似用户的行为提供可解释的候选，适合有较充足交互记录的推荐场景。"
  "本次结果体现了准确率与覆盖率之间的权衡，也表明邻居数量不能只依据运行速度或直觉确定，应在固定协议下验证。")
h("局限与改进方向", 2)
p("本实验只采用一次随机划分，未报告多种子波动或显著性；随机划分不模拟真实的时间先后部署。"
  "电影评分数据的观察偏差会影响离线命中率，新用户与新电影缺乏交互时也难以获得可靠相似度。")
p("Pearson仅设置共同评分至少3项，少量共评仍可能带来极端相关值；可进一步验证相似度收缩。"
  "当前推荐只利用高分正反馈，忽略低分的负向作用；可与均值中心化评分预测、ItemCF或矩阵分解进行同协议对比。"
  "这些属于后续方向，本报告没有将其写成已完成实验或已验证收益。")
h("复现步骤", 2)
p("使用Python 3.12，在解压后的项目目录执行以下命令。第一条实验命令从GroupLens下载缺失的数据；"
  "已有数据时可改用 --data-dir 指定包含 u.data 和 u.item 的目录。")
code("""python -m pip install -r requirements.txt
python -m unittest -v test_usercf
python usercf_experiment.py --download
python build_report.py""")
p("实验输出保存在 results 目录：JSON保存配置、统计和每次计时，CSV保存参数指标和推荐列表，PNG保存曲线，"
  "similarity_matrices.npz保存三个初始训练相似度矩阵及最终选中配置的矩阵。报告生成器读取这些输出，不在文档中手工填写实验数值。")
p("固定数据、种子与版本可复现划分和指标；运行时间随设备及系统负载变化。原始MovieLens数据不随交付包重新分发，可由脚本从发布方获取，使用条件见数据集README [1]。")
h("参考资料", 2)
p("[1] GroupLens. MovieLens 100K Dataset及README. https://grouplens.org/datasets/movielens/100k/ ；"
  "https://files.grouplens.org/datasets/movielens/ml-100k-README.txt")
p("[2] SciPy. scipy.stats.pearsonr 文档，Pearson相关系数定义与常数输入说明. "
  "https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.pearsonr.html")
p("[3] Harper F M, Konstan J A. The MovieLens Datasets: History and Context. ACM TiiS, 2015, 5(4), Article 19. DOI: 10.1145/2827872.")

output = ROOT / "实验一_UserCF实验报告_优化版.docx"
DOC.save(output)
print(output)
