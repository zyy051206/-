"""UserCF 的独立数学与边界测试；无需下载或读取 MovieLens 数据。

运行：python -m unittest -v test_usercf.py
"""
import unittest

import usercf_experiment as cf
import numpy as np


class SimilarityTests(unittest.TestCase):
    def test_cosine_matches_hand_calculation(self):
        ratings = np.array([[3, 4, 0], [3, 0, 4]], dtype=float)
        actual = cf.calc_similarity(ratings, "cosine", min_common=1)
        np.testing.assert_allclose(actual, [[0, 9 / 25], [9 / 25, 0]])

    def test_jaccard_uses_rated_sets_not_rating_magnitude(self):
        ratings = np.array([[3, 4, 0], [3, 0, 4]], dtype=float)
        expected = np.array([[0, 1 / 3], [1 / 3, 0]])
        np.testing.assert_allclose(cf.calc_similarity(ratings, "jaccard", 1), expected)
        ratings[ratings > 0] = 1
        np.testing.assert_allclose(cf.calc_similarity(ratings, "jaccard", 1), expected)

    def test_pearson_uses_only_common_items(self):
        # 非共同评分会改变用户全局均值；结果必须仍等于共同集合的相关系数。
        ratings = np.array([[1, 2, 4, 5, 0], [2, 4, 1, 0, 5]], dtype=float)
        expected = np.corrcoef([1, 2, 4], [2, 4, 1])[0, 1]
        actual = cf.calc_similarity(ratings, "pearson", min_common=3)
        self.assertAlmostEqual(actual[0, 1], expected, places=12)
        ratings[0, 3], ratings[1, 4] = 1, 2
        self.assertAlmostEqual(cf.calc_similarity(ratings, "pearson", 3)[0, 1],
                               expected, places=12)

    def test_pearson_positive_and_negative_perfect_correlation(self):
        ratings = np.array([[1, 2, 3], [2, 3, 4], [3, 2, 1]], dtype=float)
        expected = [[0, 1, -1], [1, 0, -1], [-1, -1, 0]]
        np.testing.assert_allclose(cf.calc_similarity(ratings, "pearson"), expected,
                                   atol=1e-12)

    def test_pearson_matches_pairwise_reference_on_sparse_matrix(self):
        rng = np.random.default_rng(12)
        ratings = rng.integers(1, 6, size=(8, 16)).astype(float)
        ratings[rng.random(ratings.shape) < 0.35] = 0
        expected = np.zeros((8, 8))
        for u in range(8):
            for v in range(u + 1, 8):
                common = (ratings[u] > 0) & (ratings[v] > 0)
                a, b = ratings[u, common], ratings[v, common]
                if len(a) >= 3 and np.ptp(a) > 0 and np.ptp(b) > 0:
                    expected[u, v] = expected[v, u] = np.corrcoef(a, b)[0, 1]
        np.testing.assert_allclose(cf.calc_similarity(ratings, "pearson", 3), expected,
                                   atol=1e-12)

    def test_no_overlap_and_empty_user_are_zero(self):
        ratings = np.array([[5, 0, 0], [0, 4, 0], [0, 0, 0]], dtype=float)
        for method in cf.METHODS:
            with self.subTest(method=method):
                with np.errstate(divide="raise", invalid="raise"):
                    actual = cf.calc_similarity(ratings, method, 1)
                np.testing.assert_array_equal(actual, np.zeros((3, 3)))

    def test_pearson_zero_variance_is_zero(self):
        ratings = np.array([[2, 2, 2, 0], [1, 3, 5, 4]], dtype=float)
        with np.errstate(divide="raise", invalid="raise"):
            actual = cf.calc_similarity(ratings, "pearson", 3)
        np.testing.assert_array_equal(actual, np.zeros((2, 2)))

    def test_minimum_common_items_applies_to_every_method(self):
        ratings = np.array([[1, 2, 0], [2, 4, 5]], dtype=float)
        for method in cf.METHODS:
            with self.subTest(method=method):
                self.assertGreater(cf.calc_similarity(ratings, method, 2)[0, 1], 0)
                np.testing.assert_array_equal(cf.calc_similarity(ratings, method, 3),
                                              np.zeros((2, 2)))

    def test_symmetry_bounds_diagonal_and_no_input_mutation(self):
        ratings = np.array([[1, 2, 5, 0], [5, 2, 1, 4], [3, 3, 3, 3]], dtype=float)
        original = ratings.copy()
        for method in cf.METHODS:
            with self.subTest(method=method):
                actual = cf.calc_similarity(ratings, method, 1)
                np.testing.assert_allclose(actual, actual.T, atol=1e-12)
                np.testing.assert_array_equal(np.diag(actual), np.zeros(3))
                self.assertTrue(np.isfinite(actual).all())
                self.assertTrue((np.abs(actual) <= 1).all())
        np.testing.assert_array_equal(ratings, original)

    def test_invalid_similarity_settings_raise(self):
        with self.assertRaises(ValueError):
            cf.calc_similarity(np.ones((2, 3)), "unknown")
        with self.assertRaises(ValueError):
            cf.calc_similarity(np.ones((2, 3)), "cosine", 0)


class SplitTests(unittest.TestCase):
    def setUp(self):
        self.full = np.array([
            [1, 2, 3, 0, 0, 0, 0, 0, 0, 0],
            [1, 2, 3, 4, 5, 0, 0, 0, 0, 0],
            [1, 2, 3, 4, 5, 1, 2, 3, 4, 5],
        ], dtype=float)

    def test_disjoint_reconstruction_and_nonempty_partitions(self):
        original = self.full.copy()
        parts = cf.split_by_user(self.full, seed=7)
        np.testing.assert_array_equal(sum(parts), self.full)
        for i, first in enumerate(parts):
            self.assertTrue((np.count_nonzero(first, axis=1) >= 1).all())
            for second in parts[i + 1:]:
                self.assertFalse(np.any((first > 0) & (second > 0)))
        np.testing.assert_array_equal(self.full, original)
        np.testing.assert_array_equal(np.count_nonzero(parts[0], axis=1), [1, 3, 6])

    def test_reproducible_with_same_seed(self):
        first = cf.split_by_user(self.full, seed=42)
        second = cf.split_by_user(self.full, seed=42)
        for a, b in zip(first, second):
            np.testing.assert_array_equal(a, b)

    def test_too_few_ratings_is_rejected(self):
        for ratings in (np.zeros((1, 4)), np.array([[1, 0, 0, 0]]),
                        np.array([[1, 2, 0, 0]])):
            with self.subTest(ratings=ratings.tolist()), self.assertRaises(ValueError):
                cf.split_by_user(ratings)


class RecommendationTests(unittest.TestCase):
    def setUp(self):
        self.ratings = np.array([
            [1, 0, 0, 0, 0, 0],
            [5, 4, 5, 1, 0, 0],
            [4, 0, 4, 4, 3, 0],
            [0, 0, 0, 0, 5, 5],
            [0, 0, 0, 0, 5, 5],
        ], dtype=float)
        self.similarity = np.zeros((5, 5))
        self.similarity[0] = [1, 0.6, 0.3, 0, -0.2]

    def test_neighbors_exclude_self_zero_and_negative(self):
        np.testing.assert_array_equal(cf.get_top_k_users(self.similarity, 0, 99), [1, 2])
        np.testing.assert_array_equal(cf.get_top_k_users(self.similarity, 0, 1), [1])

    def test_neighbor_ties_use_ascending_user_id(self):
        self.similarity[0] = [10, 0.5, 0.5, 0.5, -1]
        np.testing.assert_array_equal(cf.get_top_k_users(self.similarity, 0, 2), [1, 2])

    def test_weighted_likes_and_exclusion_of_all_seen_items(self):
        recs = cf.generate_recommendations(self.ratings, self.similarity, 0, 99, top_n=10)
        self.assertEqual([item for item, _ in recs], [2, 1, 3])
        np.testing.assert_allclose([score for _, score in recs], [1, 2 / 3, 1 / 3])
        self.assertTrue(all(self.ratings[0, item] == 0 for item, _ in recs))
        self.assertTrue(all(0 < score <= 1 for _, score in recs))
        self.assertEqual(cf.generate_recommendations(self.ratings, self.similarity,
                                                    0, 99, top_n=2), recs[:2])

    def test_candidate_ties_use_ascending_item_id(self):
        ratings = np.array([[5, 0, 0, 0], [0, 4, 0, 0], [0, 0, 5, 0]], dtype=float)
        similarity = np.array([[1, 0.5, 0.5], [0, 0, 0], [0, 0, 0]])
        self.assertEqual(cf.generate_recommendations(ratings, similarity, 0, 2),
                         [(1, 0.5), (2, 0.5)])

    def test_no_positive_neighbors_or_no_likes_returns_empty(self):
        self.assertEqual(cf.generate_recommendations(self.ratings, np.zeros((5, 5)), 0, 5), [])
        low_ratings = np.minimum(self.ratings, 3)
        self.assertEqual(cf.generate_recommendations(low_ratings, self.similarity, 0, 5), [])

    def test_recommend_all_includes_empty_users(self):
        actual = cf.recommend_all(self.ratings, self.similarity, 2, top_n=2)
        self.assertEqual(len(actual), len(self.ratings))
        self.assertEqual([item for item, _ in actual[0]], [2, 1])
        self.assertEqual(actual[1:], [[], [], [], []])

    def test_invalid_k_and_top_n_raise(self):
        with self.assertRaises(ValueError):
            cf.get_top_k_users(self.similarity, 0, 0)
        with self.assertRaises(ValueError):
            cf.generate_recommendations(self.ratings, self.similarity, 0, 2, top_n=0)


class EvaluationTests(unittest.TestCase):
    def test_fixed_precision_denominator_and_all_user_coverage(self):
        # 用户0有两个留出正例，仅推荐一项且命中；用户1有正例但空推荐；
        # 用户2无留出正例，其推荐仍必须计入目录和用户覆盖率。
        heldout = np.array([[5, 4, 0, 0, 0], [0, 0, 5, 0, 0], [0, 0, 0, 0, 0]])
        recs = [[(0, 0.8)], [], [(4, 0.5)]]
        actual = cf.evaluate(recs, heldout, top_n=2)
        self.assertAlmostEqual(actual["precision_at_2"], 1 / 6)
        self.assertAlmostEqual(actual["recall_at_2"], 1 / 4)
        self.assertAlmostEqual(actual["catalog_coverage"], 2 / 5)
        self.assertAlmostEqual(actual["user_coverage"], 2 / 3)
        self.assertAlmostEqual(actual["mean_list_length"], 2 / 3)
        self.assertEqual(actual["precision_users"], 3)
        self.assertEqual(actual["recall_users"], 2)
        self.assertEqual(actual["total_hits"], 1)
        self.assertEqual(actual["recommended_distinct_items"], 2)

    def test_empty_recommendations_and_no_relevant_items_are_zero(self):
        actual = cf.evaluate([[], []], np.zeros((2, 4)), top_n=3)
        for key in ("precision_at_3", "recall_at_3", "catalog_coverage",
                    "user_coverage", "mean_list_length", "total_hits"):
            with self.subTest(key=key):
                self.assertEqual(actual[key], 0)
        self.assertEqual(actual["precision_users"], 2)
        self.assertEqual(actual["recall_users"], 0)

    def test_shared_recommendations_count_once_for_catalog_coverage(self):
        actual = cf.evaluate([[(1, 0.5)], [(1, 0.4)]], np.zeros((2, 4)), top_n=1)
        self.assertEqual(actual["recommended_distinct_items"], 1)
        self.assertEqual(actual["catalog_coverage"], 0.25)

    def test_duplicate_or_oversized_lists_are_rejected(self):
        for recs, n in (([[(0, 1), (0, 0.5)]], 2), ([[(0, 1), (1, 0.5)]], 1)):
            with self.subTest(recs=recs, n=n), self.assertRaises(ValueError):
                cf.evaluate(recs, np.zeros((1, 3)), top_n=n)

    def test_invalid_user_count_and_top_n_are_rejected(self):
        with self.assertRaises(ValueError):
            cf.evaluate([[]], np.zeros((2, 3)))
        with self.assertRaises(ValueError):
            cf.evaluate([[]], np.zeros((1, 3)), top_n=0)

    def test_invalid_or_out_of_catalog_item_ids_are_rejected(self):
        for item in (-1, 3, 1.5, "1"):
            with self.subTest(item=item), self.assertRaises(ValueError):
                cf.evaluate([[(item, 0.5)]], np.zeros((1, 3)))

    def test_empty_or_invalid_heldout_dimensions_are_rejected(self):
        for heldout, recs in ((np.zeros((0, 3)), []), (np.zeros((1, 0)), [[]]),
                              (np.zeros(3), [[], [], []]), (np.zeros((1, 2, 3)), [[]])):
            with self.subTest(shape=heldout.shape), self.assertRaises(ValueError):
                cf.evaluate(recs, heldout)


if __name__ == "__main__":
    unittest.main()
